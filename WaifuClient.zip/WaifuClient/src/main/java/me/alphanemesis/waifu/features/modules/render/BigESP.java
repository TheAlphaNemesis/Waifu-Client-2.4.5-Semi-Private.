package me.alphanemesis.waifu.features.modules.render;

import me.alphanemesis.waifu.features.modules.Module;

public class BigESP
        extends Module {
    public BigESP() {
        super("BigModule", "Big fucking module", Module.Category.RENDER, true, false, false);
    }
}


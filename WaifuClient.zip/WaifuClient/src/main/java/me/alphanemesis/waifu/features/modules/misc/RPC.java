package me.alphanemesis.waifu.features.modules.misc;

import me.alphanemesis.waifu.DiscordPresence;
import me.alphanemesis.waifu.features.modules.Module;
import me.alphanemesis.waifu.features.setting.Setting;

public class RPC
        extends Module {
    public static RPC INSTANCE;
    public Setting<Boolean> catMode = this.register(new Setting<Boolean>("CatMode", false));
    public Setting<Boolean> showIP = this.register(new Setting<Boolean>("ShowIP", Boolean.valueOf(true), "Shows the server IP in your discord presence."));
    public Setting<String> state = this.register(new Setting<String>("State", "WaifuClient 2.4.5", "Sets the state of the DiscordRPC."));

    public RPC() {
        super("RPC", "Discord rich presence", Module.Category.MISC, false, false, false);
        INSTANCE = this;
    }

    @Override
    public void onEnable() {
        DiscordPresence.start();
    }

    @Override
    public void onDisable() {
        DiscordPresence.stop();
    }
}


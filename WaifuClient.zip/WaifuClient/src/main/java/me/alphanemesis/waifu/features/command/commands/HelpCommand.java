package me.alphanemesis.waifu.features.command.commands;

import me.alphanemesis.waifu.WaifuClient;
import me.alphanemesis.waifu.features.command.Command;

public class HelpCommand
        extends Command {
    public HelpCommand() {
        super("commands");
    }

    @Override
    public void execute(String[] commands) {
        HelpCommand.sendMessage("You can use following commands: ");
        for (Command command : WaifuClient.commandManager.getCommands()) {
            HelpCommand.sendMessage(WaifuClient.commandManager.getPrefix() + command.getName());
        }
    }
}


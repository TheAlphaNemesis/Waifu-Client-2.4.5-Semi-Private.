package me.alphanemesis.waifu.features.modules.render;

import me.alphanemesis.waifu.features.modules.Module;

public class RenderTest
        extends Module {
    public RenderTest() {
        super("RenderTest", "RenderTest", Module.Category.RENDER, true, false, false);
    }
}


package me.alphanemesis.waifu.util;

public class PacketUtil$ArrayOutOfBoundsException
        extends RuntimeException {
}


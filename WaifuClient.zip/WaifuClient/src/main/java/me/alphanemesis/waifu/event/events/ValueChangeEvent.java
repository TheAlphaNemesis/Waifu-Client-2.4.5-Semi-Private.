package me.alphanemesis.waifu.event.events;

import me.alphanemesis.waifu.event.EventStage;
import me.alphanemesis.waifu.features.setting.Setting;

public class ValueChangeEvent
        extends EventStage {
    public Setting setting;
    public Object value;

    public ValueChangeEvent(Setting setting, Object value) {
        this.setting = setting;
        this.value = value;
    }
}


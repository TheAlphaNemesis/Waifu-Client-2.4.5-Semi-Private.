Compatible WaifuClient 2.4.5
By AlphaNemesis
Ik There Are Some Random Crashes.
compatible with pyro, future, konas and rusher.

to build it yourself, use:


MACOS/LINUX:
./gradlew setupDecompWorkspace
./gradlew build

WINDOWS:
./gradle setupDecompWorkspace
./gradle build



